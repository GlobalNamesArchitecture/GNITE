#!/usr/bin/env ruby

f = open('DarwinCore.txt')
out = open('out', 'w')

f.each do |r|
  d = r.strip.split("\t")
  if d.size > 7
    auth = d[-1]
    d = d[0..-2]
    d[-1] = auth
    puts d.size
  end
  if d.size < 7
    n = 7 - d.size
    n.times {d << nil}
  end
  puts d.size
  out.write(d.join("\t") + "\n")
end
