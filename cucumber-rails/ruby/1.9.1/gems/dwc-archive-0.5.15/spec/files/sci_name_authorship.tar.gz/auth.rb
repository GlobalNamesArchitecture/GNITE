#!/usr/bin/env ruby

require 'biodiversity'
require 'dwc-archive'

d = DarwinCore.new('data.tar.gz')
p = ScientificNameParser.new
data  = d.core.read
data2 = []
data[0].each_with_index do |r, i|
  # r << "ScientificNameAuthorship"; data2 << r; next if i == 0
  parsed = p.parse(r[2])
  require 'ruby-debug'; debugger if i == 300
  canonical = parsed[:scientificName][:canonical]
  authorship = parsed[:scientificName][:details][0][:species] ? parsed[:scientificName][:details][0][:species][:authorship] : nil
  r[2] = canonical
  r << authorship
  data2 << r
end

f = open('out', 'w')
data2.each do |r|
  str = r.join("\t") + "\n"
  f.write(str)
end
f.close
